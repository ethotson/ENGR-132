%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ENGR 132 
% Program Description 
replace this text with your program decription as a comment
%
% Assigment Information
%   Assignment:			PS ##, Problem #
%   Author:				Name, login@purdue.edu
%   Team ID:			###-##
%   Paired Partner:		Name, login@purdue.edu
%   Contributor:		Name, login@purdue [repeat for each]
%   Our contributor(s) helped us:	
%     [ ] understand the assignment expectations without
%         telling us how they will approach it.
%     [ ] understand different ways to think about a solution
%         without helping us plan our solution.
%     [ ] think through the meaning of a specific error or
%         bug present in our code without looking at our code.
did you complete the assignment information? delete this line if yes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% ____________________
%% INITIALIZATION



%% ____________________
%% SUBPLOT FIGURE



%% ____________________
%% LINEARIZATION



%% ____________________
%% UPTAKE MODEL



%% ____________________
%% PREDICTIONS



%% ____________________
%% ANALYSIS

%% -- Q1
% 


%% -- Q2
% 



%% ____________________
%% ACADEMIC INTEGRITY STATEMENT
% We have not used source code obtained from any other unauthorized
% source, either modified or unmodified.  Neither have we provided
% access to our code to another. The script we are submitting
% is our own original work.